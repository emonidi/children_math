var BoardManager = function(){
	var self = this;
	this.numberOfSquares = 0;
	this.holderElement;
	this.fragment;
	this.squares = [];
	

	this._getHolderElement = function(element){
		var holderElement = !this.holderElement ? document.getElementById(element) : this.holderElement;
		return holderElement; 
	}

	this._createDocumentFragment = function(){
		this.fragment = document.createDocumentFragment();
		return this.fragment;
	}

	this._setEventListeners = function(square,squareIndex){
		square.addEventListener("click",function(){
			self._unhiglightAll();
			var squareObj = self.squares[squareIndex-1];
			squareObj.highlite("blue");
			for(var i = 0, ii = self.squares.length; i<ii;i++){
				if(parseInt(squareIndex)%self.squares[i].squareNumber == 0){
					self.squares[i].highlite("red");
				}
			}
		},false)
	}

	this._unhiglightAll = function(){
		for(var i = 0,ii = self.squares.length;i<ii;i++){
			self.squares[i].highlite("white");
		}
	}

	//public methods
	return{
		setNumberOfSquares:function(numberOfSquares){
			self.numberOfSquares = numberOfSquares;
			return self.numberOfSquares;
		},
		getNumberOfSquares:function(){
			return self.numberOfSquares;
		},
		createBoard:function(numberOfSquares,holderElement){
			var fragment = self._createDocumentFragment();
			var ns = this.setNumberOfSquares(numberOfSquares);
			
			var element = self._getHolderElement(holderElement);
			for(var i = 1; i <= ns; i++){
				
				var square = new Square(i);
				self.squares.push(square);
				fragment.appendChild(square.initialize());	
				self._setEventListeners(square.html,i);
			}
			element.appendChild(fragment)
		}
	}
}


